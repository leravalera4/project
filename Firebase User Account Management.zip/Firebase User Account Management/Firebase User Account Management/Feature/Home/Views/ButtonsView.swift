//
//  ButtonsView.swift
//  Firebase User Account Management
//
//  Created by Валерия on 04.06.2022.
//

import SwiftUI

struct ButtonsView: View {
    
    @State private var showsHomeView = false
    //@State private var showsCameraView = false
    @State var product: String = ""
    
    var body: some View {
        NavigationView {            
            VStack(alignment: .leading,
                   spacing: 16) {
                Button(action: {
                    setProduct("product 1")
                }) {
                    Text("Product 1")
                        .frame(maxWidth: .infinity, maxHeight: 50)
                    //.padding(.all)
                    //.padding(.vertical, 50)
                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .foregroundColor(.white)
                    //.cornerRadius(25)
                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .font(.system(size: 16, weight: .bold))
                        .cornerRadius(10)
                }
                
                
                
                Button(action: {
                    setProduct("product 2")
                }) {
                    Text("Product 2")
                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
                    //.padding(.all)
                    //.padding(.vertical, 50)
                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .foregroundColor(.white)
                    //.cornerRadius(25)
                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .font(.system(size: 16, weight: .bold))
                        .cornerRadius(10)
                }
                
                
                
                Button(action: {
                    setProduct("product 3")
                }) {
                    Text("Product 3")
                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
                    //.padding(.all)
                    //.padding(.vertical, 50)
                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .foregroundColor(.white)
                    //.cornerRadius(25)
                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .font(.system(size: 16, weight: .bold))
                        .cornerRadius(10)
                }
                
                Button(action: {
                    setProduct("product 4")
                }) {
                    Text("Product 4")
                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
                    //.padding(.all)
                    //.padding(.vertical, 50)
                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .foregroundColor(.white)
                    //.cornerRadius(25)
                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .font(.system(size: 16, weight: .bold))
                        .cornerRadius(10)
                }
                
                Button(action: {
                    setProduct("product 5")
                }) {
                    Text("Product 5")
                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
                    //.padding(.all)
                    //.padding(.vertical, 50)
                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .foregroundColor(.white)
                    //.cornerRadius(25)
                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .font(.system(size: 16, weight: .bold))
                        .cornerRadius(10)
                }
                
                
//                Button(action: {
//                    setProduct("product 6")
//                }) {
//                    Text("Product 6")
//                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
//                    //.padding(.all)
//                    //.padding(.vertical, 50)
//                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
//                        .foregroundColor(.white)
//                    //.cornerRadius(25)
//                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
//                        .font(.system(size: 16, weight: .bold))
//                        .cornerRadius(10)
//                }
//                
//                Button(action: {
//                    setProduct("product 7")
//                }) {
//                    Text("Product 7")
//                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
//                    //.padding(.all)
//                    //.padding(.vertical, 50)
//                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
//                        .foregroundColor(.white)
//                    //.cornerRadius(25)
//                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
//                        .font(.system(size: 16, weight: .bold))
//                        .cornerRadius(10)
//                }
//                
//                
//                Button(action: {
//                    setProduct("product 8")
//                }) {
//                    Text("Product 8")
//                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
//                    //.padding(.all)
//                    //.padding(.vertical, 50)
//                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
//                        .foregroundColor(.white)
//                    //.cornerRadius(25)
//                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
//                        .font(.system(size: 16, weight: .bold))
//                        .cornerRadius(10)
//                }
//                
//                Button(action: {
//                    setProduct("product 9")
//                }) {
//                    Text("Product 9")
//                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
//                    //.padding(.all)
//                    //.padding(.vertical, 50)
//                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
//                        .foregroundColor(.white)
//                    //.cornerRadius(25)
//                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
//                        .font(.system(size: 16, weight: .bold))
//                        .cornerRadius(10)
//                }
//                
//                Button(action: {
//                    setProduct("product 10")
//                }) {
//                    Text("Product 10")
//                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
//                    //.padding(.all)
//                    //.padding(.vertical, 50)
//                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
//                        .foregroundColor(.white)
//                    //.cornerRadius(25)
//                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
//                        .font(.system(size: 16, weight: .bold))
//                        .cornerRadius(10)
//                }
                
                
            }

            }.padding(.horizontal, 16)
            .padding(.vertical, 60)
            .navigationTitle("Products")
        
        .sheet(isPresented: $showsHomeView) {
            //.sheet(isPresented: $showsCameraView) {
            HomeView(product: $product)
            //CameraView()
        }

    }
    
    func setProduct(_ product: String) {
        self.product = product
        self.showsHomeView = true
    }
    
    
    
}




struct ButtonsView_Previews: PreviewProvider {
    static var previews: some View {
        ButtonsView()
    }
}
