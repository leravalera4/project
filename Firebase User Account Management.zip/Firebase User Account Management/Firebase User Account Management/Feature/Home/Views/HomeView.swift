////
////  HomeView.swift
////  Firebase User Account Management
////
////  Created by Tunde on 22/05/2021.
////
//
import SwiftUI
import MessageUI

struct HomeView: View {

    @EnvironmentObject var service: SessionServiceImpl
    @State var showEmailComposer = false
    @State var showHelloView = false
    @State var showPictureView = false
    @Binding var product: String
    @State private var showImagePicker: Bool = false
    @State private var image: Image? = nil
    


    var body: some View {
        VStack(alignment: .leading,
               spacing: 16) {
//                          LottieView(lottieFile: "mail")
//                              .frame(width: 400, height: 400)

            VStack(alignment: .leading,
                   spacing: 16) {
                LottieView(lottieFile: "mail")
            //    .frame(width: 300, height: 300)
                            //  .resizable()
                  .scaledToFit()
                  .padding(.horizontal,2)
                //                    Image("image-one")
                //                                .resizable()
                //                                .scaledToFit()
//                image?.resizable()
//                    .scaledToFit()
//
//                Button("Attach the image") {
//                    self.showImagePicker = true
//                }.padding()
//                    .background(Color.blue)
//                    .foregroundColor(Color.white)
//                    .cornerRadius(10)
//            }.sheet(isPresented: self.$showImagePicker) {
//                PhotoCaptureView(showImagePicker: self.$showImagePicker, image: self.$image)
//            }
                Button(action: {showHelloView = true}, label:{
                    Text("Attach an image")
                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
                    //.padding(.all)
                    //.padding(.vertical, 50)
                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .foregroundColor(.white)
                    //.cornerRadius(25)
                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .font(.system(size: 16, weight: .bold))
                        .cornerRadius(10)
                }).sheet(isPresented: $showHelloView) {
                    HelloView()
                }
                    
                Button(action: {
                    print(product)
                    showEmailComposer = true
                }, label: {
                    Text("Report a problem")
                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
                    //.padding(.all)
                    //.padding(.vertical, 50)
                        .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .foregroundColor(.white)
                    //.cornerRadius(25)
                        .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                        .font(.system(size: 16, weight: .bold))
                        .cornerRadius(10)
                })
                .sheet(isPresented: $showEmailComposer) {
                    MailView(
                        recepiens:"lab@nbits.ca",
                        subject: "I have a problem with \(product)",
                        message: "Message",
                        attachment: nil,
                        onResult: { _ in
                            // Handle the result if needed.
                            self.showEmailComposer = false
                        }
                    )
                }


                ButtonView(title: "Logout",
                           background: .clear,
                           foreground:.init(red: 66/255, green: 73/255, blue: 178/255),
                           border: .init(red: 66/255, green: 73/255, blue: 178/255)) {
                    service.logout()
                }

            }
                   .padding(.horizontal, 16)
                   .padding(.vertical, 60)
                   .navigationTitle("Contact us")


        }
    }

    struct HomeView_Previews: PreviewProvider {
        static var previews: some View {
            NavigationView {
                HomeView(product: .constant("product 1"))
                    .environmentObject(SessionServiceImpl())
            }
        }
    }


}
