//
//  HelloView.swift
//  Firebase User Account Management
//
//  Created by Валерия on 08.06.2022.
//

import SwiftUI

struct HelloView: View {

    @State private var showImagePicker: Bool = false
    @State private var image: Image? = nil

    var body: some View {
        VStack {

            image?.resizable()
                .scaledToFit()

            Button("Take a picture") {
                self.showImagePicker = true
            }.padding()
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: 50)
            //.padding(.all)
            //.padding(.vertical, 50)
                .background(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                .foregroundColor(.white)
            //.cornerRadius(25)
                .border(Color(red: 66 / 255, green: 73 / 255, blue: 178 / 255))
                .font(.system(size: 16, weight: .bold))
                .cornerRadius(10)
        }.sheet(isPresented: self.$showImagePicker) {
            PhotoCaptureView(showImagePicker: self.$showImagePicker, image: self.$image)
        }
    }
}
